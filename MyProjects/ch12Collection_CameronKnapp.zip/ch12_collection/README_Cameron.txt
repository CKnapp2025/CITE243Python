"""
===========================================================
Program Name: Deploying Python Programs
Author: Cameron Knapp
Date: 2025-09-29
Description:
    This guide explains how to make my existing Python
    scripts easy to run either by creating shell/batch
    scripts or by compiling them into standalone executables
    with PyInstaller. This applies to:
        - Back Up a Folder into a ZIP File
        - Extract Contact Information from Large Documents
        - Add Bullets to Wiki Markup
        - Interactive Chessboard Simulator
        - Any other project scripts
    
Usage
	1.) Refer to instruction below.
===========================================================
"""
NOTES FROM CAMERON -- 
1.) I used the bash script method. [i.e. Place the 'executable batches' path into a folder on PATH via Environmental variables on Windows.]
2.) I am currently running Windows 11 and Python v3.10.7 on my home machine.
3.) Certain programs need dependencies before running thru Command Prompt. Run these for each file:
	backup_to_zip    - pip install zipfile    AND   pip install os
	bulletsWiki      - pip install pyperclip   
	chessboard       - pip install sys        AND   pip install copy
	extractContacts  - pip install pyperclip  AND   pip install re
	selectiveCopying - pip install shutil     AND   pip install os
4.) Run the file in command prompt (with administrative privileges) by simply typing in the name of the file. 
	